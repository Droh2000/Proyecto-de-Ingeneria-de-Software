package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConsultaVisualizarPlano extends conexionBD{
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean buscarRazonSocial(solicitud s,cliente c,plano p,estadoPlano est){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("select cliente.nombreCliente,cliente.apellidosCliente,plano.tipo,estadoplano.estado from solicitud,cliente,plano,estadoplano where solicitud.idCliente=cliente.idCliente and plano.idCliente=cliente.idCliente and plano.idEstado=estadoplano.idEstado and solicitud.idSolicitud=?");
            ps.setInt(1, s.getIdSolicitud());
            rs = ps.executeQuery();
            
            if(rs.next()){
                c.setNombreCliente(rs.getString("nombreCliente"));
                c.setApellidosCliente(rs.getString("apellidosCliente"));
                p.setTipo(rs.getString("tipo"));
                est.setEstado(rs.getString("estado"));
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
}
