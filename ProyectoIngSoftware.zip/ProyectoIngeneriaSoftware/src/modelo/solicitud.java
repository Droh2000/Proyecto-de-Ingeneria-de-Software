package modelo;

import java.sql.Date;

public class solicitud {
    private int idSolicitud;
    private Date fechaSoli;
    private String horaSoli;
    private String detalleSoli;
    private int idEmpleado;
    private int idCliente;

    public int getIdSolicitud() {
        return idSolicitud;
    }

    public void setIdSolicitud(int idSolicitud) {
        this.idSolicitud = idSolicitud;
    }

    public Date getFechaSoli() {
        return fechaSoli;
    }

    public void setFechaSoli(Date fechaSoli) {
        this.fechaSoli = fechaSoli;
    }

    public String getHoraSoli() {
        return horaSoli;
    }

    public void setHoraSoli(String horaSoli) {
        this.horaSoli = horaSoli;
    }

    public String getDetalleSoli() {
        return detalleSoli;
    }

    public void setDetalleSoli(String detalleSoli) {
        this.detalleSoli = detalleSoli;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
    
    
    
}
