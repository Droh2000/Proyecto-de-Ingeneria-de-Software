package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ConsultasGenerarTicket extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    //Buscar si existe la Solicitud del cliente
    public boolean buscarSolicitud(solicitud s,cliente c,empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("select * from Cliente,Solicitud,Empleado where Solicitud.idEmpleado=Empleado.idEmpleado and Solicitud.idCliente=Cliente.idCliente and Solicitud.idSolicitud=?");
                ps.setInt(1, s.getIdSolicitud());
                rs = ps.executeQuery();

                if(rs.next()){//Si es verdadero es que encontramos datos
                    c.setNombreCliente(rs.getString("nombreCliente"));
                    s.setDetalleSoli(rs.getString("detalleSoli"));
                    em.setIdEmpleado(rs.getInt("idEmpleado"));
                    em.setNombreEmpleado(rs.getString("nombreEmpleado"));
                    em.setApellidosPaterno(rs.getString("apellidosPaterno"));
                    em.setApellidosMaterno(rs.getString("apellidosMaterno"));
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean registroTicket(Ticket t){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into Ticket (fechaTicket,detalle,total,idEmpleado)"
                        + " values (curdate(),?,?,?)");
                ps.setString(1,t.getDetalle());
                ps.setFloat(2, t.getTotal());
                ps.setInt(3, t.getIdEmpleado());
                
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
}
