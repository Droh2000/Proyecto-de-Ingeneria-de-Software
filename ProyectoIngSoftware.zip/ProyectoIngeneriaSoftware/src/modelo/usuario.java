package modelo;

import java.sql.Date;

public class usuario {
    private int idUsuaio;
    private String nombreUser;
    private String contraseña;
    private String privilegio;
    private Date fecha;
    private int idEmpleado;

    public int getIdUsuaio() {
        return idUsuaio;
    }

    public void setIdUsuaio(int idUsuaio) {
        this.idUsuaio = idUsuaio;
    }

    public String getNombreUser() {
        return nombreUser;
    }

    public void setNombreUser(String nombreUser) {
        this.nombreUser = nombreUser;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getPrivilegio() {
        return privilegio;
    }

    public void setPrivilegio(String privilegio) {
        this.privilegio = privilegio;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }
    
    
}
