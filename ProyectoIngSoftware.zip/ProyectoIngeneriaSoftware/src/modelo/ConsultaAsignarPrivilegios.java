package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ConsultaAsignarPrivilegios extends conexionBD{
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean consultarEmpleadoUsuario(empleado em,usuario u){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("select * from empleado,usuario where empleado.idEmpleado=usuario.idEmpleado and empleado.DNI=?");
                ps.setString(1, em.getDNI());
                rs = ps.executeQuery();

                if(rs.next()){//Si es verdadero es que encontramos datos
                    em.setIdEmpleado(rs.getInt("idEmpleado"));
                    em.setCargo(rs.getString("cargo"));
                    u.setNombreUser(rs.getString("nombreUser"));
                    u.setPrivilegio(rs.getString("privilegio"));
                    u.setFecha(rs.getDate("fecha"));
                    u.setIdUsuaio(rs.getInt("idUsuaio"));
                    return true;
                }else{
                    consultarEmpleado(em);
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean consultarEmpleado(empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("select * from empleado where DNI=?");
                ps.setString(1, em.getDNI());
                rs = ps.executeQuery();

                if(rs.next()){//Si es verdadero es que encontramos datos
                    em.setIdEmpleado(rs.getInt("idEmpleado"));
                    em.setCargo(rs.getString("cargo"));
                    JOptionPane.showMessageDialog(null,"El empleado no tiene Usuario\nIngrese los datos Faltantes");
                    return true;
                }else{
                    JOptionPane.showMessageDialog(null, "No existe ese Empleado");
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean guardar(usuario u){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into usuario (nombreUser,contraseña,privilegio,fecha,idEmpleado)" +
                                            "values (?,?,?,?,?)");
                ps.setString(1, u.getNombreUser());
                ps.setString(2, u.getContraseña());
                ps.setString(3, u.getPrivilegio());
                ps.setDate(4, u.getFecha());
                ps.setInt(5, u.getIdEmpleado());
                //Queremos hacer un INSER
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public int verificarUsuario(String u){//Si retorna 0 es que no hay ningun usuario con ese Nombre
        Connection conexion=getConnection();
        try {
            //Saber si ya existe un Usuario, Si nos lanza 1 quiere decit que ya existe un Usuario para que se ponga otro nombre
            ps=conexion.prepareStatement("select count(idUsuaio) from Usuario where nombreUser=?");
            ps.setString(1, u);
            //Queremos hacer un INSER
            rs =ps.executeQuery();
            if(rs.next()){//si se cumple es que nos retorna un conteo
                return rs.getInt(1);
            }else{
                return 1;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return 1;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean modificar(usuario u){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("update usuario set nombreUser=?,contraseña=?,privilegio=?,fecha=?,idEmpleado=? where idUsuaio=?");
                ps.setString(1, u.getNombreUser());
                ps.setString(2, u.getContraseña());
                ps.setString(3, u.getPrivilegio());
                ps.setDate(4, u.getFecha());
                ps.setInt(5, u.getIdEmpleado());
                ps.setInt(6, u.getIdUsuaio());
                //Queremos hacer un UPDATE
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
}
