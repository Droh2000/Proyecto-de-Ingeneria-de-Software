package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CosultaLogin extends conexionBD{
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean iniciarSesion(usuario u){
        Connection conexion=getConnection();
        try {
            
            ps=conexion.prepareStatement("select idUsuaio,nombreUser,contraseña,privilegio,idEmpleado from Usuario where nombreUser=?");
            ps.setString(1, u.getNombreUser());
            rs =ps.executeQuery();
            if(rs.next()){//Indica que el Nombre de usuario si corresponde aun usuario en la Base de Datos
                //Ahora comprobamos la contraaseña
                if(u.getContraseña().equals(rs.getString("contraseña"))){
                    u.setIdUsuaio(rs.getInt("idUsuaio"));
                    u.setNombreUser(rs.getString("nombreUser"));
                    u.setPrivilegio(rs.getString("privilegio"));
                    u.setIdEmpleado(rs.getInt("idEmpleado"));
                    return true;
                }else{//La contraseña no es correcta
                    return false;
                }
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
