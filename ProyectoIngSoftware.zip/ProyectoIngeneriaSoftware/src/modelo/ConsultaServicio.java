package modelo;

import java.sql.*;
import javax.swing.JOptionPane;

public class ConsultaServicio extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    //Buscar si existe la razonSocial del cliente
    public boolean buscarRazonSocial(cliente c,solicitud s){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("select * from Solicitud,Cliente where Solicitud.idCliente=Cliente.idCliente and razonSocial=?");
                ps.setString(1, c.getRazonSocial());
                rs = ps.executeQuery();

                if(rs.next()){//Si es verdadero es que encontramos la Persona
                    c.setRazonSocial(rs.getString("razonSocial"));
                    c.setIdCliente(rs.getInt("idCliente"));
                    c.setNombreCliente(rs.getString("nombreCliente"));
                    c.setDireccion(rs.getString("direccion"));
                    c.setCiudad(rs.getString("ciudad"));
                    c.setApellidosCliente(rs.getString("apellidosCliente"));
                    c.setTelefono(rs.getString("telefono"));
                    c.setEmail(rs.getString("email"));
                    //Obtener su No Solicitud, Fecha y Hora
                    s.setIdSolicitud(rs.getInt("idSolicitud"));
                    s.setDetalleSoli(rs.getString("detalleSoli"));
                    s.setFechaSoli(rs.getDate("fechaSoli"));
                    s.setHoraSoli(rs.getString("horaSoli"));
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean registroClienteSolicitud(cliente c,usuario u){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into Cliente (nombreCliente,apellidosCliente,razonSocial,direccion,ciudad,telefono,email)"
                    + " values (?,?,?,?,?,?,?)");
                ps.setString(1, c.getNombreCliente());
                ps.setString(2, c.getApellidosCliente());
                ps.setString(3, c.getRazonSocial());
                ps.setString(4, c.getDireccion());
                ps.setString(5, c.getCiudad());
                ps.setString(6, c.getTelefono());
                ps.setString(7, c.getEmail());
                
                int resu=ps.executeUpdate();
                if(resu>0){
                   registroSolicitud(u);
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public void registroSolicitud(usuario u){
        Connection conexion=getConnection();
        try {
            //if(){
                Statement sentencia=conexion.createStatement();
                String consulta="select MAX(idCliente) from cliente";
                rs=sentencia.executeQuery(consulta);
                ps=conexion.prepareStatement("insert into Solicitud (fechaSoli,horaSoli,detalleSoli,idEmpleado,idCliente) " +
                "values (curdate(),CURTIME(),'',?,?)");
                ps.setInt(1, u.getIdEmpleado());
                while(rs.next()) {
                    ps.setInt(2, rs.getInt(1));
                }
                int resu=ps.executeUpdate();
                if(resu>0){
                    JOptionPane.showMessageDialog(null,"Solicitud Guardada Correctamente");
                    rs.close();
                }else{
                    JOptionPane.showMessageDialog(null,"Solicitud No se Guardo");
                    rs.close();
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean modificarDetalleSolicitud(solicitud s){
        Connection conexion=getConnection();
        try {
            //if(){
                ps = conexion.prepareStatement("update Solicitud set detalleSoli=? where idSolicitud=?");
                ps.setString(1, s.getDetalleSoli());
                ps.setInt(2, s.getIdSolicitud());
                
                int resu = ps.executeUpdate();
                
                if(resu>0){//Si se modifico correctamente
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean actualizarDatosClienteDetalle(cliente c,solicitud s){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("update Cliente set nombreCliente=?,apellidosCliente=?,razonSocial=?,direccion=?"
                        + ",ciudad=?,telefono=?,email=? where idCliente=?");
                
                ps.setString(1, c.getNombreCliente());
                ps.setString(2, c.getApellidosCliente());
                ps.setString(3, c.getRazonSocial());
                ps.setString(4, c.getDireccion());
                ps.setString(5, c.getCiudad());
                ps.setString(6, c.getTelefono());
                ps.setString(7, c.getEmail());
                ps.setInt(8, c.getIdCliente());
                
                int resu=ps.executeUpdate();
                
                if(resu>0){
                    if(modificarDetalleSolicitud(s)){
                        JOptionPane.showMessageDialog(null,"Detalle Guardada Correctamente");
                    }else{
                        JOptionPane.showMessageDialog(null,"Detalle de la solicitud no se guardo");
                    }
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
}
