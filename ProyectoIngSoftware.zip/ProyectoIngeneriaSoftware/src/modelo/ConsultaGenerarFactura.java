package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class ConsultaGenerarFactura extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    public boolean buscarRazonSocial(cliente c,estadoPlano est){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("select Cliente.idCliente,Cliente.direccion,Cliente.ciudad,Plano.idEstado from Cliente,Plano where Plano.idCliente=Cliente.idCliente and Cliente.razonSocial=?");
            ps.setString(1, c.getRazonSocial());
            rs = ps.executeQuery();

            if(rs.next()){//Si es verdadero es que encontramos la Persona
                c.setIdCliente(rs.getInt("idCliente"));
                c.setDireccion(rs.getString("direccion"));
                c.setCiudad(rs.getString("ciudad"));
                est.setIdEstado(rs.getInt("idEstado"));
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean verificarSolicitud(cliente c,empleado emp){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("select * from solicitud where idCliente=?");
            ps.setInt(1, c.getIdCliente());

            rs = ps.executeQuery();

            if(rs.next()){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean crearFacturayDetalle(factura f,detalleFactura df,cliente c,estadoPlano est){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("insert into Factura (idCliente,idEstado,FechaFactura,HoraFactura)"
                    + " values (?,?,?,CURTIME())");
            ps.setInt(1,c.getIdCliente());
            ps.setInt(2, est.getIdEstado());
            ps.setDate(3, f.getFechaFactura());

            int resu=ps.executeUpdate();

            if(resu>0){
                Statement sentencia=conexion.createStatement();
                String consulta="select MAX(idFactura) from Factura";
                rs=sentencia.executeQuery(consulta);

                while(rs.next()) {
                    f.setIdFactura(rs.getInt(1));
                }
                crearDetalle(f, df);
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    public void crearDetalle(factura f,detalleFactura df){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into Detalle (cantidad,producto,precioUnitario,importeTotal,idFactura)"
                        + " values (?,?,?,?,?)");
                ps.setInt(1,df.getCantidad());
                ps.setString(2, df.getProducto());
                ps.setFloat(3, df.getPrecioUnitario());
                ps.setFloat(4, df.getImporteTotal());
                ps.setInt(5,f.getIdFactura());
                int resu=ps.executeUpdate();
                if(resu>0){
                    JOptionPane.showMessageDialog(null, "El detalle de la factura se Creo Correctamente");
                    
                }else{
                    JOptionPane.showMessageDialog(null, "El detalle de la factura No se Creo");
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            JOptionPane.showMessageDialog(null, "El detalle de la factura No se Creo");
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
