package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ConsultaReporteTicket extends conexionBD{
    PreparedStatement ps;
    ResultSet rs;
    
    public DefaultTableModel buscarDatos(){
        Connection conexion=getConnection();
        DefaultTableModel modelo=new DefaultTableModel();
            modelo.addColumn("Fecha");
            modelo.addColumn("Hora");
            modelo.addColumn("Cliente");
            modelo.addColumn("Ticket");
            modelo.addColumn("Costo");
        try {
            ps=conexion.prepareStatement("select Solicitud.fechaSoli,Solicitud.horaSoli,cliente.nombreCliente,ticket.idTicket,ticket.total from Cliente,Solicitud,ticket where Solicitud.idCliente=Cliente.idCliente and Solicitud.idEmpleado=ticket.idEmpleado");
            
            rs = ps.executeQuery();

            while(rs.next()){
                Object[] fila=new Object[5];//Cada arreglo fila guarda un registro(dentro de cada registro nececitamos 5 datos)
                for (int i = 0; i < 5; i++) {//Porque son 5 filas
                    fila[i]=rs.getObject(i+1);
                }
                modelo.addRow(fila);//Todo lo que vayamos obtneniendo de la base d e datos lo agregamos alas filas de la tabla
            }
               return modelo;
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return null;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean obtenerFechaSolicitud(solicitud s){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("select Solicitud.fechaSoli from Cliente,Solicitud,ticket where Solicitud.idCliente=Cliente.idCliente and Solicitud.idEmpleado=ticket.idEmpleado");
            rs = ps.executeQuery();
            
            if(rs.next()){
                s.setFechaSoli(rs.getDate("fechaSoli"));
            }
            return true;
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
