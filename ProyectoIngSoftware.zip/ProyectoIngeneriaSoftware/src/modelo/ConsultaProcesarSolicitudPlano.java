package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class ConsultaProcesarSolicitudPlano extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    public DefaultTableModel cargarSolicitud(){
        Connection conexion=getConnection();
        DefaultTableModel modelo=new DefaultTableModel();
            modelo.addColumn("No. Solicitud");
            modelo.addColumn("Fecha");
            modelo.addColumn("Hora");
            modelo.addColumn("Detalle");
            modelo.addColumn("Cliente");
            modelo.addColumn("Estado");
        try {
            //if(){
                ps=conexion.prepareStatement("select Solicitud.idSolicitud,Solicitud.fechaSoli,Solicitud.horaSoli,Solicitud.detalleSoli,Cliente.nombreCliente,estadoplano.estado from solicitud,Cliente,estadoplano,plano where Solicitud.idCliente=Cliente.idCliente and solicitud.idCliente=plano.idCliente and estadoplano.idEstado=plano.idEstado");
                
                rs = ps.executeQuery();
                
                while(rs.next()){
                    Object[] fila=new Object[6];//Cada arreglo fila guarda un registro(dentro de cada registro nececitamos 5 datos)
                    for (int i = 0; i < 6; i++) {//Porque son 5 filas
                        fila[i]=rs.getObject(i+1);
                    }
                    modelo.addRow(fila);//Todo lo que vayamos obtneniendo de la base d e datos lo agregamos alas filas de la tabla
                }
               return modelo; 
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return null;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public DefaultTableModel buscarSolicitud(solicitud s,plano p){
        Connection conexion=getConnection();
        DefaultTableModel modelo=new DefaultTableModel();
            modelo.addColumn("No. Solicitud");
            modelo.addColumn("Fecha");
            modelo.addColumn("Hora");
            modelo.addColumn("Detalle");
            modelo.addColumn("Cliente");
            modelo.addColumn("Estado");
        try {
            ps=conexion.prepareStatement("select Solicitud.idSolicitud,Solicitud.fechaSoli,Solicitud.horaSoli,Solicitud.detalleSoli,Cliente.nombreCliente,estadoplano.estado from solicitud,Cliente,estadoplano,plano where Solicitud.idCliente=Cliente.idCliente and solicitud.idCliente=plano.idCliente and estadoplano.idEstado=plano.idEstado and solicitud.idSolicitud=?");
            ps.setInt(1,s.getIdSolicitud());
            rs = ps.executeQuery();
            while(rs.next()){
                Object[] fila=new Object[6];//Cada arreglo fila guarda un registro(dentro de cada registro nececitamos 5 datos)
                for (int i = 0; i < 6; i++) {//Porque son 5 filas
                    fila[i]=rs.getObject(i+1);
                }
                modelo.addRow(fila);//Todo lo que vayamos obtneniendo de la base d e datos lo agregamos alas filas de la tabla
            }
           return modelo;
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return null;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean encontrarIdPlano(solicitud s,plano p){
        Connection conexion=getConnection();
        try {
            Statement sentencia=conexion.createStatement();
            String consulta="select Plano.idPlano from solicitud,Cliente,estadoplano,plano where Solicitud.idCliente=Cliente.idCliente and solicitud.idCliente=plano.idCliente and estadoplano.idEstado=plano.idEstado and solicitud.idSolicitud="+s.getIdSolicitud();
            rs=sentencia.executeQuery(consulta);
            while(rs.next()) {
                p.setIdPlano(rs.getInt("idPlano"));
            }
            rs.close();
            return true;
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean registrarEstadoPlano(estadoPlano estado,plano p){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("update Plano set idEstado=? where idPlano=?");
            ps.setInt(1,estado.getIdEstado());
            ps.setInt(2,p.getIdPlano());

            int resu=ps.executeUpdate();

            if(resu>0){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean actualizarEstadoFecha(estadoPlano estado){
        Connection conexion=getConnection();
        try {
            ps=conexion.prepareStatement("update EstadoPlano set fechaEstado=? where idEstado=?");
            ps.setDate(1,estado.getFechaEstado());
            ps.setInt(2,estado.getIdEstado());

            int resu=ps.executeUpdate();

            if(resu>0){
                return true;
            }else{
                return false;
            }
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
