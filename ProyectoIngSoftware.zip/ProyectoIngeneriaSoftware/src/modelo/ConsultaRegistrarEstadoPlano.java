package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ConsultaRegistrarEstadoPlano extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    public DefaultTableModel cargarEstados(estadoPlano est){
        Connection conexion=getConnection();
        DefaultTableModel modelo=new DefaultTableModel();
            modelo.addColumn("Codigo");
            modelo.addColumn("Estado");
        try {
            //if(){
                ps=conexion.prepareStatement("select idEstado,estado from EstadoPlano where idEstado=?");
                ps.setInt(1,est.getIdEstado());

                rs = ps.executeQuery();

                while(rs.next()){
                    Object[] fila=new Object[2];//Cada arreglo fila guarda un registro(dentro de cada registro nececitamos 5 datos)
                    for (int i = 0; i < 2; i++) {//Porque son 5 filas
                        fila[i]=rs.getObject(i+1);
                    }
                    modelo.addRow(fila);//Todo lo que vayamos obtneniendo de la base d e datos lo agregamos alas filas de la tabla
                }
               return modelo;
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return null;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean registroEstado(estadoPlano est){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into EstadoPlano (fechaEstado,estado)"
                        + " values (curdate(),?)");
                ps.setString(1, est.getEstado());
                
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public DefaultTableModel cargarTodaTabla(){
        Connection conexion=getConnection();
        DefaultTableModel modelo=new DefaultTableModel();
            modelo.addColumn("Codigo");
            modelo.addColumn("Estado");
        try {
            //if(){
                ps=conexion.prepareStatement("select idEstado,estado from EstadoPlano");
              
                rs = ps.executeQuery();

                while(rs.next()){
                    Object[] fila=new Object[2];//Cada arreglo fila guarda un registro(dentro de cada registro nececitamos 5 datos)
                    for (int i = 0; i < 2; i++) {//Porque son 5 filas
                        fila[i]=rs.getObject(i+1);
                    }
                    modelo.addRow(fila);//Todo lo que vayamos obtneniendo de la base d e datos lo agregamos alas filas de la tabla
                }
               return modelo;
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return null;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
}
