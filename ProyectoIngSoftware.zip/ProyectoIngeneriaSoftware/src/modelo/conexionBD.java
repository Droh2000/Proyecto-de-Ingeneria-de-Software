package modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class conexionBD {//vamos hacer la conexion ala base de datos, aqui va la libreria
    public static final String URL="jdbc:mysql://localhost:3306/prueba?autoReconnet=true&useSSL=false";
    public static final String usuario="root";
    public static final String contraeña="1234";
    
    //Metodo para retornar una conexion
    public Connection getConnection(){
        Connection conexion=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion= (Connection) DriverManager.getConnection(URL,usuario,contraeña);
        } catch (Exception e) {
            System.err.println("Error: "+e);
        }
        return conexion;
    }
}
