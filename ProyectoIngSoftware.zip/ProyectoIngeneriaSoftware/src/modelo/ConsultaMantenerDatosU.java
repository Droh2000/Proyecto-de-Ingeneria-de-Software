package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConsultaMantenerDatosU extends conexionBD{
    PreparedStatement ps;
    ResultSet rs;
    
    public boolean consultarEmpleado(empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("select * from Empleado where DNI=?");
                ps.setString(1, em.getDNI());
                rs = ps.executeQuery();

                if(rs.next()){//Si es verdadero es que encontramos datos
                    em.setIdEmpleado(rs.getInt("idEmpleado"));
                    em.setNombreEmpleado(rs.getString("nombreEmpleado"));
                    em.setApellidosPaterno(rs.getString("apellidosPaterno"));
                    em.setApellidosMaterno(rs.getString("apellidosMaterno"));
                    em.setDireccion(rs.getString("direccion"));
                    em.setSueldo(rs.getFloat("sueldo"));
                    em.setTelefono(rs.getString("telefono"));
                    em.setCargo(rs.getString("cargo"));
                    em.setSexo(rs.getString("sexo"));
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean guardar(empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into Empleado (nombreEmpleado,apellidosPaterno,apellidosMaterno,DNI,direccion,sueldo,telefono,cargo,sexo) " +
                                            "values (?,?,?,?,?,?,?,?,?)");
                ps.setString(1, em.getNombreEmpleado());
                ps.setString(2, em.getApellidosPaterno());
                ps.setString(3, em.getApellidosMaterno());
                ps.setString(4, em.getDNI());
                ps.setString(5, em.getDireccion());
                ps.setFloat(6, em.getSueldo());
                ps.setString(7, em.getTelefono());
                ps.setString(8, em.getCargo());
                ps.setString(9, em.getSexo());
                //Queremos hacer un INSER
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean modificar(empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("update Empleado set nombreEmpleado=?,apellidosPaterno=?,apellidosMaterno=?,DNI=?,direccion=?,sueldo=?,telefono=?,cargo=?,sexo=? " +
                                            "where idEmpleado=?");
                ps.setString(1, em.getNombreEmpleado());
                ps.setString(2, em.getApellidosPaterno());
                ps.setString(3, em.getApellidosMaterno());
                ps.setString(4, em.getDNI());
                ps.setString(5, em.getDireccion());
                ps.setFloat(6, em.getSueldo());
                ps.setString(7, em.getTelefono());
                ps.setString(8, em.getCargo());
                ps.setString(9, em.getSexo());
                ps.setInt(10, em.getIdEmpleado());
                //Queremos hacer un UPDATE
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
    
    public boolean eliminar(empleado em){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("delete from Empleado where idEmpleado=?");
                ps.setInt(1, em.getIdEmpleado());
                
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
