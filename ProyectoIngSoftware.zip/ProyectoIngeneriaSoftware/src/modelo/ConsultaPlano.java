package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConsultaPlano extends conexionBD{
    PreparedStatement ps;//Hacer las consultas
    ResultSet rs;//obtener algo de la BD
    
    public boolean registroPlano(plano p){
        Connection conexion=getConnection();
        try {
            //if(){
                ps=conexion.prepareStatement("insert into Plano (tipo,graduacion,escala,mapa,tamaño,idCliente,idEstado)"
                    + " values (?,?,?,?,?,?,?)");
                ps.setString(1, p.getTipo());
                ps.setString(2, p.getGraduacion());
                ps.setFloat(3, p.getEscala());
                ps.setString(4, p.getMapa());
                ps.setFloat(5, p.getTamaño());
                ps.setInt(6, p.getIdCliente());
                ps.setInt(7, p.getIdEstado());
                
                int resu=ps.executeUpdate();
                if(resu>0){
                    return true;
                }else{
                    return false;
                }
            //}
        } catch (Exception e) {
            System.err.println("Error: "+e);
            return false;
        }finally{
            try {
                conexion.close();//Cerramos la conexion con la base de datos
            } catch (Exception e) {
                System.err.println("Error: "+e);
            }
        }
    }
}
