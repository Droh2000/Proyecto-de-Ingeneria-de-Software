package principal;

import controlador.ControladorAsignarPrivilegios;
import controlador.ControladorGenerarTicket;
import controlador.ControladorLogin;
import controlador.ControladorMantenerDatosU;
import controlador.ControladorProcesarSolicitudPlano;
import controlador.ControladorRegistrarEstadoPlano;
import controlador.ControladorServicio;
import controlador.ControladroEliminarSolicitud;
import controlador.ControladroGenerarFactura;
import modelo.ConsultaAsignarPrivilegios;
import modelo.ConsultaEliminarSolicitud;
import modelo.ConsultaGenerarFactura;
import modelo.ConsultaMantenerDatosU;
import modelo.ConsultaProcesarSolicitudPlano;
import modelo.ConsultaRegistrarEstadoPlano;
import modelo.ConsultaServicio;
import modelo.ConsultasGenerarTicket;
import modelo.CosultaLogin;
import modelo.Ticket;
import modelo.cliente;
import modelo.detalleFactura;
import modelo.empleado;
import modelo.estadoPlano;
import modelo.factura;
import modelo.plano;
import modelo.solicitud;
import modelo.usuario;
import vista.AsignarPrivilegios;
import vista.EliminarSolicitudPlano;
import vista.GenerarFactura;
import vista.GenerarSolicitudServicio;
import vista.GenerarTicketRegistro;
import vista.Login;
import vista.MantenerDatosUsuario;
import vista.ProcesarSolicitudPlano;
import vista.RegistrarEstadoPlano;

public class Arranque {
    public static void main(String[] args) {
        usuario user=new usuario();
        /*GenerarSolicitudServicio vistaS=new GenerarSolicitudServicio();
        cliente c=new cliente();
        solicitud s=new solicitud();
        ConsultaServicio modelo=new ConsultaServicio();
        plano Plano=new plano();//Este es el que se agrego NUEVO
        ControladorServicio control=new ControladorServicio(vistaS,Plano,c, user,s, modelo);
        control.iniciar();*/
        
        //GenerarTicketRegistro ticketV =new GenerarTicketRegistro();
        empleado emp=new empleado();
        /*Ticket tick=new Ticket();
        ConsultasGenerarTicket modeloTicket=new ConsultasGenerarTicket();
        ControladorGenerarTicket controlTicket=new ControladorGenerarTicket(ticketV,c,tick,s, emp, modeloTicket);
        controlTicket.iniciar();*/
        
        /*EliminarSolicitudPlano elimSol=new EliminarSolicitudPlano();
        ConsultaEliminarSolicitud modeloElim=new ConsultaEliminarSolicitud();
        ControladroEliminarSolicitud controlElim = new ControladroEliminarSolicitud(elimSol, c, s, emp, modeloElim);
        controlElim.iniciar();*/
        
        /*ProcesarSolicitudPlano vistaPSP=new ProcesarSolicitudPlano();
        //estadoPlano estado=new estadoPlano();
        ConsultaProcesarSolicitudPlano cpsp=new ConsultaProcesarSolicitudPlano();
        ControladorProcesarSolicitudPlano cps=new ControladorProcesarSolicitudPlano(vistaPSP, c, s, estado, cpsp);
        cps.Iniciar();*/
        
        /*RegistrarEstadoPlano vistaREP=new RegistrarEstadoPlano();
        ConsultaRegistrarEstadoPlano consuREP=new ConsultaRegistrarEstadoPlano();
        ControladorRegistrarEstadoPlano contrREP=new ControladorRegistrarEstadoPlano(vistaREP, consuREP, estado);
        contrREP.Inicio();*/
        
        /*GenerarFactura fact=new GenerarFactura();
        ConsultaGenerarFactura consFact=new ConsultaGenerarFactura();
        //factura f=new factura();
        //detalleFactura df=new detalleFactura();
        ControladroGenerarFactura cgf=new ControladroGenerarFactura(fact, consFact, c, s, estado, f, df);
        cgf.inicar();*/
        
        /*MantenerDatosUsuario mdu=new MantenerDatosUsuario();
        ConsultaMantenerDatosU consuMDU= new ConsultaMantenerDatosU();
        ControladorMantenerDatosU controlMDU=new ControladorMantenerDatosU(mdu, consuMDU, emp);
        controlMDU.iniciar();*/
        
        /*AsignarPrivilegios ap=new AsignarPrivilegios();
        ConsultaAsignarPrivilegios consuAP=new ConsultaAsignarPrivilegios();
        ControladorAsignarPrivilegios controlAP=new ControladorAsignarPrivilegios(ap, consuAP, emp, user);
        controlAP.iniciar();*/
        
        Login log=new Login();
        CosultaLogin cosuLog=new CosultaLogin();
        ControladorLogin contrLog=new ControladorLogin(log, cosuLog, user);
        contrLog.iniciar();
    }
}
