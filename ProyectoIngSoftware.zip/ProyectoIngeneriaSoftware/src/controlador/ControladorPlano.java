package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JOptionPane;
import modelo.ConsultaPlano;
import modelo.ConsultaRegistrarEstadoPlano;
import modelo.estadoPlano;
import modelo.plano;
import vista.RegistrarEstadoPlano;
import vista.RegistroPlano;

public class ControladorPlano implements ActionListener{
    private RegistroPlano vista;
    private ConsultaPlano consulta;
    private plano Plano;
    public static RegistrarEstadoPlano vistaREP2;

    public ControladorPlano(RegistroPlano vista, ConsultaPlano consulta, plano Plano) {
        this.vista = vista;
        this.consulta = consulta;
        this.Plano = Plano;
        //vista.cajaIdCliente.setText(String.valueOf(Plano.getIdCliente()));
        vista.btnRegistrar.addActionListener(this);
        vista.btnVerEsatado.addActionListener(this);
        //Cuando se Cierre la Ventana
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorServicio.vistaPlano=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnRegistrar){
            Plano.setTipo(vista.cajaTipo.getText());
            Plano.setGraduacion(vista.cajaGruadacion.getText());
            Plano.setEscala(Float.parseFloat(vista.cajaEscala.getText()));
            Plano.setMapa(vista.cajaMapa.getText());
            Plano.setTamaño(Float.parseFloat(vista.cajaTamaño.getText()));
            Plano.setIdEstado(Integer.parseInt(vista.cajaIdEmpleado.getText()));
            if(consulta.registroPlano(Plano)){
                JOptionPane.showMessageDialog(null, "Plano Registrado Correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "El Plano No se pudo egistrar");
            }
        }
        if(e.getSource()==vista.btnVerEsatado){
            if(vistaREP2==null){
                vistaREP2=new RegistrarEstadoPlano();
                ConsultaRegistrarEstadoPlano consuREP=new ConsultaRegistrarEstadoPlano();
                estadoPlano estado=new estadoPlano();
                ControladorRegistrarEstadoPlano contrREP=new ControladorRegistrarEstadoPlano(vistaREP2, consuREP, estado);
                contrREP.inicioPlano();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya tienes Abierta la Ventana");
            }
        }
    }
    
    public void Inicio(){
        vista.setSize(570,275);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.cajaIdCliente.setVisible(false);
    }

}
