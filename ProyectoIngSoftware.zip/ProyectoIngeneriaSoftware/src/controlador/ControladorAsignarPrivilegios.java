package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import javax.swing.JOptionPane;
import modelo.CifrarContraseña;
import modelo.ConsultaAsignarPrivilegios;
import modelo.empleado;
import modelo.usuario;
import vista.AsignarPrivilegios;

public class ControladorAsignarPrivilegios implements ActionListener{
    private AsignarPrivilegios vista;
    private ConsultaAsignarPrivilegios consulta;
    private empleado emp;
    private usuario user;

    public ControladorAsignarPrivilegios(AsignarPrivilegios vista, ConsultaAsignarPrivilegios consulta, empleado emp, usuario user) {
        this.vista = vista;
        this.consulta = consulta;
        this.emp = emp;
        this.user = user;
        vista.btnConsultar.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnModificar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnConsultar){
            if(!vista.cajaDNI.getText().isEmpty()){
                emp.setDNI(vista.cajaDNI.getText());
                if(consulta.consultarEmpleadoUsuario(emp,user)){
                    vista.cajaIDEmp.setText(String.valueOf(emp.getIdEmpleado()));
                    vista.cajaCargo.setText(emp.getCargo());
                    vista.cajaUsuario.setText(user.getNombreUser());
                    vista.txtFecha.setDate(user.getFecha());
                    vista.comboPrivilegios.setSelectedItem(user.getPrivilegio());
                    vista.cajaIdUsuario.setText(String.valueOf(user.getIdUsuaio()));
                    vista.btnModificar.setEnabled(true);
                }else{
                    vista.cajaIDEmp.setText(String.valueOf(emp.getIdEmpleado()));
                    vista.cajaCargo.setText(emp.getCargo());
                    vista.btnGuardar.setEnabled(true);
                }   
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese el DNI del Empleado");
            }
        }
        if(e.getSource()==vista.btnGuardar){
            String contraseña=new String(vista.cajaContraseña.getPassword());
            if(vista.cajaUsuario.getText().equals("") || contraseña.equals("") || vista.cajaDNI.getText().equals("") || vista.cajaCargo.getText().equals("") || vista.txtFecha==null || vista.comboPrivilegios.getSelectedItem().equals("Seleccionar")){
                JOptionPane.showMessageDialog(null, "Llene todas las cajas");
            }else{
                //Verificar que No Existe un Usuario con el Mismo Nombre
                if(consulta.verificarUsuario(vista.cajaUsuario.getText())==0){
                    //La contraseña Cifrada(Esta se gurda en la base de datos)
                    String nuevaCon=CifrarContraseña.md5(contraseña);

                    user.setNombreUser(vista.cajaUsuario.getText());
                    user.setContraseña(nuevaCon);
                    user.setPrivilegio(vista.comboPrivilegios.getSelectedItem().toString());
                    Date fecha=vista.txtFecha.getDate();
                    long d=fecha.getTime();
                    java.sql.Date soloFecha=new java.sql.Date(d);
                    user.setFecha(soloFecha);
                    user.setIdEmpleado(Integer.parseInt(vista.cajaIDEmp.getText()));
                    if(consulta.guardar(user)){
                        JOptionPane.showMessageDialog(null, "Usuario Registrado Correctamente");
                        vista.btnGuardar.setEnabled(false);
                        LimpiarCajas();
                    }else{
                        JOptionPane.showMessageDialog(null, "Usuario no se pudo registrar");
                        vista.btnGuardar.setEnabled(false);
                        LimpiarCajas();
                    }       
                }else{
                    JOptionPane.showMessageDialog(null, "El Usuario ya existe con ese Nombre");
                }
            }
        }
        if(e.getSource()==vista.btnModificar){
            String contraseña=new String(vista.cajaContraseña.getPassword());
            if(vista.cajaUsuario.getText().equals("") || contraseña.equals("") || vista.cajaDNI.getText().equals("") || vista.cajaCargo.getText().equals("") || vista.txtFecha==null || vista.comboPrivilegios.getSelectedItem().equals("Seleccionar")){
                JOptionPane.showMessageDialog(null, "Llene todas las cajas");
            }else{
               //La contraseña Cifrada(Esta se gurda en la base de datos)
               String nuevaCon=CifrarContraseña.md5(contraseña);
                
               user.setIdUsuaio(Integer.parseInt(vista.cajaIdUsuario.getText()));
               user.setNombreUser(vista.cajaUsuario.getText());
               user.setContraseña(nuevaCon);
               user.setPrivilegio(vista.comboPrivilegios.getSelectedItem().toString());
               Date fecha=vista.txtFecha.getDate();
               long d=fecha.getTime();
               java.sql.Date soloFecha=new java.sql.Date(d);
               user.setFecha(soloFecha);
               user.setIdEmpleado(Integer.parseInt(vista.cajaIDEmp.getText()));
               if(consulta.modificar(user)){
                   JOptionPane.showMessageDialog(null, "Usuario Actualizado Correctamente");
                   vista.btnModificar.setEnabled(false);
                   LimpiarCajas();
               }else{
                   JOptionPane.showMessageDialog(null, "El Usuario No se pudo Actualizar");
                   vista.btnModificar.setEnabled(false);
                   LimpiarCajas();
               }   
            }
        }
        if(e.getSource()==vista.btnSalir){
            vista.dispose();
        }
        if(e.getSource()==vista.btnLimpiar){
            LimpiarCajas();
        }
    }
    
    public void iniciar(){
        //Le establecemos paramteros ala vista
        vista.setTitle("Asignar Privilegios");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.btnGuardar.setEnabled(false);
        vista.btnModificar.setEnabled(false);
        vista.cajaIDEmp.setVisible(false);
        vista.cajaIdUsuario.setVisible(false);
    }
    
    public void LimpiarCajas(){
        vista.cajaIdUsuario.setText(null);
        vista.cajaIDEmp.setText(null);
        vista.cajaDNI.setText(null);
        vista.cajaUsuario.setText(null);
        vista.cajaCargo.setText(null);
        vista.cajaContraseña.setText(null);
        vista.txtFecha.setDate(null);
        vista.comboPrivilegios.setSelectedIndex(0);
    }
    
}
