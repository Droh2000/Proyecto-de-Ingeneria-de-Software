package controlador;

import static controlador.ControladorInicio.vistaReporte;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaReporteTicket;
import modelo.solicitud;
import vista.ReporteGeneracionTicket;

public class ControladorReporteTicket implements ActionListener{
    private ReporteGeneracionTicket vista;
    private ConsultaReporteTicket consulta;
    private solicitud s;

    public ControladorReporteTicket(ReporteGeneracionTicket vista,solicitud s,ConsultaReporteTicket consulta) {
        this.vista = vista;
        this.s=s;
        this.consulta=consulta;
        vista.btnGenerarReporteTicket.addActionListener(this);
        vista.btnEnviar.addActionListener(this);
        vista.btnImprimir.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.vistaReporte=null;
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnGenerarReporteTicket){
            vista.tablaTicket.setModel(consulta.buscarDatos());
            if(consulta.obtenerFechaSolicitud(s)){
                vista.txtDesde.setDate(s.getFechaSoli());
                vista.btnEnviar.setEnabled(true);
                vista.btnImprimir.setEnabled(true);
            }
        }
        if(e.getSource()==vista.btnEnviar){
            JOptionPane.showMessageDialog(null, "Se Envio el Registro");
        }
        if(e.getSource()==vista.btnSalir){
            ControladorInicio.vistaReporte=null;
            vista.dispose();
        }
    }
    
    public void Inicio(){
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.btnEnviar.setEnabled(false);
        vista.btnImprimir.setEnabled(false);
    }
    
}
