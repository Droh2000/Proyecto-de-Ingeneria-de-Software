package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaReporteAtencionCliente;
import modelo.solicitud;
import vista.ReporteAtencionCliente;

public class ControladorReporteAtencionCliente implements ActionListener{
    private ReporteAtencionCliente vista;
    private ConsultaReporteAtencionCliente consulta;
    private solicitud s;

    public ControladorReporteAtencionCliente(ReporteAtencionCliente vista, ConsultaReporteAtencionCliente consulta, solicitud s) {
        this.vista = vista;
        this.consulta = consulta;
        this.s = s;
        vista.btnGenerarReporte.addActionListener(this);
        vista.btnEnviar.addActionListener(this);
        vista.btnImprimir.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.vistaReporteAtencion=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vista.btnGenerarReporte){
            vista.tablaClientes.setModel(consulta.buscarDatos());
            if(consulta.obtenerFechaSolicitud(s)){
                vista.txtDesde.setDate(s.getFechaSoli());
            }
        }
        if(e.getSource() == vista.btnEnviar){
            JOptionPane.showMessageDialog(null, "Se Envio el Registro");
        }
        if(e.getSource() == vista.btnImprimir){
            JOptionPane.showMessageDialog(null, "Se Mando a Imprimir el Registro");
        }
        if(e.getSource() == vista.btnSalir){
            ControladorInicio.vistaReporteAtencion=null;
            vista.dispose();
        }
    }
    
    public void Inicio(){
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
    
}
