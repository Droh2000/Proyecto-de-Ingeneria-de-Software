package controlador;

import static controlador.ControladorInicio.VistaticketRegistro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import modelo.ConsultaGenerarFactura;
import modelo.cliente;
import modelo.detalleFactura;
import modelo.empleado;
import modelo.estadoPlano;
import modelo.factura;
import modelo.solicitud;
import vista.GenerarFactura;

public class ControladroGenerarFactura implements ActionListener{
    private GenerarFactura vista;
    private ConsultaGenerarFactura consulta;
    private cliente cliente;
    private solicitud soli;
    private estadoPlano estado;
    private empleado emp;
    private factura fac;
    private detalleFactura detFac;

    public ControladroGenerarFactura(GenerarFactura vista, ConsultaGenerarFactura consulta, cliente cliente, solicitud soli, estadoPlano estado, factura fac, detalleFactura detFac) {
        this.vista = vista;
        this.consulta = consulta;
        this.cliente = cliente;
        this.soli = soli;
        this.estado = estado;
        this.fac = fac;
        this.detFac = detFac;
        vista.btnBuscar.addActionListener(this);
        vista.btnVerificarSoli.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnImprimir.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        //Cuando se Cierre la Ventana
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.VistaticketRegistro=null;
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnBuscar){
            if(vista.cajaRazonSocial.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Ingrese la razon social");
            }else{
                 cliente.setRazonSocial(vista.cajaRazonSocial.getText());
                if(consulta.buscarRazonSocial(cliente, estado)){
                    vista.cajaIDCliente.setText(String.valueOf(cliente.getIdCliente()));
                    vista.cajaIDestado.setText(String.valueOf(estado.getIdEstado()));
                    vista.cajaDireccion.setText(cliente.getDireccion());
                    vista.cajaCiudad.setText(cliente.getCiudad());
                    vista.btnVerificarSoli.setEnabled(true);
                }else{
                    JOptionPane.showMessageDialog(null, "No se pudo encontrar al Cliente");
                }   
            }
        }
        if(e.getSource()==vista.btnVerificarSoli){
            if(consulta.verificarSolicitud(cliente,emp)){
                JOptionPane.showMessageDialog(null, "Si existe la Solicitud del cliente\nPuede escribir la Factura");
                vista.cajaCantidad.setEnabled(true);
                vista.cajaProducto.setEnabled(true);
                vista.cajaImporte.setEnabled(true);
                vista.cajaPrecioUni.setEnabled(true);
            }else{
                JOptionPane.showMessageDialog(null, "No se pudo encontrar la solicitud del Cliente");
            }
        }
        if(e.getSource()==vista.btnGuardar){
            if(vista.txtFecha.getDate()==null && vista.cajaCantidad.getText().isEmpty() && vista.cajaProducto.getText().isEmpty() && vista.cajaPrecioUni.getText().isEmpty() && vista.cajaImporte.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Llene Todos los Campos\nPara completar la Factura");
            }else{
               Date fecha=vista.txtFecha.getDate();
               long d=fecha.getTime();
               java.sql.Date soloFecha=new java.sql.Date(d);
               fac.setFechaFactura(soloFecha);
               //*** Valores de Detalle Factura ***/
               detFac.setCantidad(Integer.parseInt(vista.cajaCantidad.getText()));
               detFac.setProducto(vista.cajaProducto.getText());
               detFac.setPrecioUnitario(Float.parseFloat(vista.cajaPrecioUni.getText()));
               detFac.setImporteTotal(Float.parseFloat(vista.cajaImporte.getText()));

               if(consulta.crearFacturayDetalle(fac, detFac, cliente, estado)){
                   JOptionPane.showMessageDialog(null, "Factura Registrada Correctamente");
                   vista.btnImprimir.setEnabled(true);
               }else{
                   JOptionPane.showMessageDialog(null, "La Factura no se pudo Registrar");
               }   
            }
        }
        if(e.getSource()==vista.btnImprimir){
            JOptionPane.showMessageDialog(null, "Se Imprimio la Factura");
        }
        if(e.getSource()==vista.btnSalir){
            ControladorInicio.vistaGenerarfact=null;
            vista.dispose();
        }
    }
    
    public void inicar(){
        vista.setTitle("Generar Factura");
        vista.setLocationRelativeTo(null);
        vista.setSize(761,466);
        vista.setVisible(true);
        vista.btnImprimir.setEnabled(false);
        vista.cajaIDCliente.setVisible(false);
        vista.cajaIDestado.setVisible(false);
        vista.cajaIDEmpleado.setVisible(false);
        vista.cajaDireccion.setEditable(false);
        vista.cajaCiudad.setEditable(false);
        vista.btnVerificarSoli.setEnabled(false);
        vista.cajaNumFactura.setEnabled(false);
        vista.cajaCantidad.setEnabled(false);
        vista.cajaProducto.setEnabled(false);
        vista.cajaImporte.setEnabled(false);
        vista.cajaPrecioUni.setEnabled(false);
    }
}
