package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import modelo.ConsultaAsignarPrivilegios;
import modelo.ConsultaEliminarSolicitud;
import modelo.ConsultaGenerarFactura;
import modelo.ConsultaMantenerDatosU;
import modelo.ConsultaProcesarSolicitudPlano;
import modelo.ConsultaRegistrarEstadoPlano;
import modelo.ConsultaReporteAtencionCliente;
import modelo.ConsultaReporteTicket;
import modelo.ConsultaServicio;
import modelo.ConsultaVisualizarPlano;
import modelo.ConsultasGenerarTicket;
import modelo.CosultaLogin;
import modelo.Ticket;
import modelo.cliente;
import modelo.detalleFactura;
import modelo.empleado;
import modelo.estadoPlano;
import modelo.factura;
import modelo.plano;
import modelo.solicitud;
import modelo.usuario;
import vista.AsignarPrivilegios;
import vista.EliminarSolicitudPlano;
import vista.GenerarFactura;
import vista.GenerarSolicitudServicio;
import vista.GenerarTicketRegistro;
import vista.Inicio;
import vista.Login;
import vista.MantenerDatosUsuario;
import vista.ProcesarSolicitudPlano;
import vista.RegistrarEstadoPlano;
import vista.ReporteAtencionCliente;
import vista.ReporteGeneracionTicket;
import vista.VisualizarPlano;

public class ControladorInicio implements ActionListener{
    private Inicio vista;
    private usuario user=new usuario();
    private cliente c=new cliente();
    private solicitud s=new solicitud();
    private empleado emp=new empleado();
    private estadoPlano estado=new estadoPlano();
    private Ticket tick=new Ticket();
    private factura f=new factura();
    private plano Plano=new plano();
    private detalleFactura df=new detalleFactura();
    //Para que no se habran mas de una vez las ventanas
    public static GenerarFactura vistaGenerarfact;//Tiene que ser la vista no el Controlador
    public static VisualizarPlano vistaVisualizarPlano;
    public static ReporteAtencionCliente vistaReporteAtencion;
    public static GenerarTicketRegistro VistaticketRegistro;
    public static GenerarSolicitudServicio vistaGenerarSolicitud;
    public static ReporteGeneracionTicket vistaReporte;
    public static EliminarSolicitudPlano elimSol;
    public static ProcesarSolicitudPlano vistaPSP;
    public static RegistrarEstadoPlano vistaREP;
    
    public ControladorInicio(usuario u) {
        vista = new Inicio();
        user=u;
        vista.setTitle("Inicio de Sesion");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.cajaIdEmpleado.setText(String.valueOf(u.getIdEmpleado()));
        vista.cajaIdEmpleado.setVisible(false);
        vista.setExtendedState(JFrame.MAXIMIZED_BOTH);
        ArranqueBotones();
        //Evento de Botones
        vista.menuCerrarSesion.addActionListener(this);
        //Eventos del Diseñador
        vista.btnEliminarSolicitud.addActionListener(this);
        vista.btnProcesarSolicitudPlano.addActionListener(this);
        vista.btnRegistrarEstadoPlano.addActionListener(this);
        //Eventos del Registrador
        vista.btnGenerarSolicitudServicio.addActionListener(this);
        vista.btnGenerarTicketRegistro.addActionListener(this);
        vista.btnGenerarReporteTicket.addActionListener(this);
        //Eventos de Atencion Clientes
        vista.btnGenerarFactura.addActionListener(this);
        vista.btnViisualizarPlano.addActionListener(this);
        vista.btnGenerarReporteAtencion.addActionListener(this);
        //Eventos de Administrador
        vista.btnMantenerDatosUser.addActionListener(this);
        vista.btnAsignarPrivilegios.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.menuCerrarSesion){
            Login log=new Login();
            CosultaLogin cosuLog=new CosultaLogin();
            ControladorLogin contrLog=new ControladorLogin(log, cosuLog, user);
            contrLog.menuInicio=null;
            contrLog.iniciar();
            vista.dispose();
        }
        if(e.getSource()==vista.btnEliminarSolicitud){
            if(elimSol==null){
                elimSol=new EliminarSolicitudPlano();
                ConsultaEliminarSolicitud modeloElim=new ConsultaEliminarSolicitud();
                ControladroEliminarSolicitud controlElim = new ControladroEliminarSolicitud(elimSol, c, s, emp, modeloElim);
                controlElim.iniciar();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnProcesarSolicitudPlano){
            if(vistaPSP==null){
                vistaPSP=new ProcesarSolicitudPlano();
                ConsultaProcesarSolicitudPlano cpsp=new ConsultaProcesarSolicitudPlano();
                ControladorProcesarSolicitudPlano cps=new ControladorProcesarSolicitudPlano(vistaPSP, c, s, estado, cpsp);
                cps.Iniciar();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnRegistrarEstadoPlano){
            if(vistaREP==null){
                vistaREP=new RegistrarEstadoPlano();
                ConsultaRegistrarEstadoPlano consuREP=new ConsultaRegistrarEstadoPlano();
                ControladorRegistrarEstadoPlano contrREP=new ControladorRegistrarEstadoPlano(vistaREP, consuREP, estado);
                contrREP.Inicio();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGenerarSolicitudServicio){
            if(vistaGenerarSolicitud==null){
               vistaGenerarSolicitud=new GenerarSolicitudServicio();
               ConsultaServicio modelo=new ConsultaServicio();
               ControladorServicio control=new ControladorServicio(vistaGenerarSolicitud,Plano,c,user,s, modelo);
               control.iniciar();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGenerarTicketRegistro){
            if(VistaticketRegistro==null){
               VistaticketRegistro= new GenerarTicketRegistro();
               ConsultasGenerarTicket modeloTicket=new ConsultasGenerarTicket();
               ControladorGenerarTicket controlTicket=new ControladorGenerarTicket(VistaticketRegistro,c,tick,s, emp, modeloTicket);
               controlTicket.iniciar();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGenerarReporteTicket){
            if(vistaReporte==null){
                vistaReporte=new ReporteGeneracionTicket();
                ConsultaReporteTicket consulta=new ConsultaReporteTicket();
                ControladorReporteTicket contr=new ControladorReporteTicket(vistaReporte, s, consulta);
                contr.Inicio();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGenerarFactura){
            if(vistaGenerarfact==null){
                vistaGenerarfact=new GenerarFactura();
                ConsultaGenerarFactura consFact=new ConsultaGenerarFactura();
                ControladroGenerarFactura cgf=new ControladroGenerarFactura(vistaGenerarfact, consFact, c, s, estado, f, df);
                cgf.inicar(); 
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnViisualizarPlano){
            if(vistaVisualizarPlano==null){
               vistaVisualizarPlano =new VisualizarPlano();
               ConsultaVisualizarPlano consulta=new ConsultaVisualizarPlano();
               ControladorVisualizarPlano contr=new ControladorVisualizarPlano(vistaVisualizarPlano, consulta, s, c, Plano, estado);
               contr.inicio();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGenerarReporteAtencion){
            if(vistaReporteAtencion==null){
               vistaReporteAtencion=new ReporteAtencionCliente();
               ConsultaReporteAtencionCliente cnr=new ConsultaReporteAtencionCliente();
               ControladorReporteAtencionCliente contr=new ControladorReporteAtencionCliente(vistaReporteAtencion, cnr, s);
               contr.Inicio();   
            }else{
                JOptionPane.showMessageDialog(null, "Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnMantenerDatosUser){
            MantenerDatosUsuario mdu=new MantenerDatosUsuario();
            ConsultaMantenerDatosU consuMDU= new ConsultaMantenerDatosU();
            ControladorMantenerDatosU controlMDU=new ControladorMantenerDatosU(mdu, consuMDU, emp);
            controlMDU.iniciar();
        }
        if(e.getSource()==vista.btnAsignarPrivilegios){
            AsignarPrivilegios ap=new AsignarPrivilegios();
            ConsultaAsignarPrivilegios consuAP=new ConsultaAsignarPrivilegios();
            ControladorAsignarPrivilegios controlAP=new ControladorAsignarPrivilegios(ap, consuAP, emp, user);
            controlAP.iniciar();
        }
    }
    
    public void ArranqueBotones(){
        if(user.getPrivilegio().equals("Diseñador")){
            vista.panelAdministradorSis.setVisible(false);
            vista.panelAtencionClientes.setVisible(false);
            vista.panelRegistradorSoli.setVisible(false);
        }
        if(user.getPrivilegio().equals("Atencion Clientes")){
            vista.paneDiseñador.setVisible(false);
            vista.panelAdministradorSis.setVisible(false);
            vista.panelRegistradorSoli.setVisible(false);
        }
        if(user.getPrivilegio().equals("Administrador del Sistema")){
            vista.paneDiseñador.setVisible(false);
            vista.panelAtencionClientes.setVisible(false);
            vista.panelRegistradorSoli.setVisible(false);
        }
        if(user.getPrivilegio().equals("Registrador de la Solicitud")){
             vista.panelAdministradorSis.setVisible(false);
            vista.panelAtencionClientes.setVisible(false);
            vista.paneDiseñador.setVisible(false);
        }
    }

}
