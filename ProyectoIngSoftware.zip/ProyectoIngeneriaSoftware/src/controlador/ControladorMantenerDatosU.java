package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.ConsultaMantenerDatosU;
import modelo.empleado;
import vista.MantenerDatosUsuario;

public class ControladorMantenerDatosU implements ActionListener{
    private MantenerDatosUsuario vista;
    private ConsultaMantenerDatosU consulta;
    private empleado emp;

    public ControladorMantenerDatosU(MantenerDatosUsuario vista, ConsultaMantenerDatosU consulta, empleado emp) {
        this.vista = vista;
        this.consulta = consulta;
        this.emp = emp;
        vista.btnConsultar.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnModificar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnConsultar){
            emp.setDNI(vista.cajaDNI.getText());
            if(consulta.consultarEmpleado(emp)){
                vista.cajaIdEmpleado.setText(String.valueOf(emp.getIdEmpleado()));
                vista.cajaNombre.setText(emp.getNombreEmpleado());
                vista.cajaPaterno.setText(emp.getApellidosPaterno());
                vista.cajaMaterno.setText(emp.getApellidosMaterno());
                vista.cajaTelefono.setText(emp.getTelefono());
                vista.cajaSueldo.setText(String.valueOf(emp.getSueldo()));
                vista.cajaDireccion.setText(emp.getDireccion());
                vista.comboSexo.setSelectedItem(emp.getSexo());
                vista.comboCargo.setSelectedItem(emp.getCargo());
            }else{
                JOptionPane.showMessageDialog(null, "No se Encontro el cliente\nIngrese el Registro");
            }
        }
        if(e.getSource()==vista.btnGuardar){
            emp.setDNI(vista.cajaDNI.getText());
            emp.setNombreEmpleado(vista.cajaNombre.getText());
            emp.setApellidosPaterno(vista.cajaPaterno.getText());
            emp.setApellidosMaterno(vista.cajaMaterno.getText());
            emp.setTelefono(vista.cajaTelefono.getText());
            emp.setSueldo(Float.parseFloat(vista.cajaSueldo.getText()));
            emp.setDireccion(vista.cajaDireccion.getText());
            emp.setSexo(vista.comboSexo.getSelectedItem().toString());
            emp.setCargo(vista.comboCargo.getSelectedItem().toString());
            if(consulta.guardar(emp)){
                JOptionPane.showMessageDialog(null, "Empleado Registrado Correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "El Empleado No se pudo Registrar");
            }
        }
        if(e.getSource()==vista.btnModificar){
            emp.setIdEmpleado(Integer.parseInt(vista.cajaIdEmpleado.getText()));
            emp.setDNI(vista.cajaDNI.getText());
            emp.setNombreEmpleado(vista.cajaNombre.getText());
            emp.setApellidosPaterno(vista.cajaPaterno.getText());
            emp.setApellidosMaterno(vista.cajaMaterno.getText());
            emp.setTelefono(vista.cajaTelefono.getText());
            emp.setSueldo(Float.parseFloat(vista.cajaSueldo.getText()));
            emp.setDireccion(vista.cajaDireccion.getText());
            emp.setSexo(vista.comboSexo.getSelectedItem().toString());
            emp.setCargo(vista.comboCargo.getSelectedItem().toString());
            if(consulta.modificar(emp)){
                JOptionPane.showMessageDialog(null, "Empleado Actualizado Correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "El Empleado No se pudo Actualizar");
            }
        }
        if(e.getSource()==vista.btnEliminar){
            emp.setIdEmpleado(Integer.parseInt(vista.cajaIdEmpleado.getText()));
            if(consulta.eliminar(emp)){
                JOptionPane.showMessageDialog(null, "Empleado Eliminado Correctamente");
            }else{
                JOptionPane.showMessageDialog(null, "El Empleado No se pudo Eliminar");
            }
        }
        if(e.getSource()==vista.btnSalir){
            vista.setVisible(false);
        }
        if(e.getSource()==vista.btnLimpiar){
            //Limpiar Cajas
        }
    }
    
    public void iniciar(){
        //Le establecemos paramteros ala vista
        vista.setTitle("Mantener Datos del Usuario");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
        vista.cajaIdEmpleado.setVisible(false);
    }  
    
}
