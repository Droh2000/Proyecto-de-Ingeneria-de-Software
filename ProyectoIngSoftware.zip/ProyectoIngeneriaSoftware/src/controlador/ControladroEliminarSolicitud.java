package controlador;

import static controlador.ControladorInicio.elimSol;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaEliminarSolicitud;
import modelo.cliente;
import modelo.empleado;
import modelo.solicitud;
import vista.EliminarSolicitudPlano;

public class ControladroEliminarSolicitud implements ActionListener{
    private EliminarSolicitudPlano vista;
    private cliente Cliente;//objeto con todos los atributos del cliente
    private solicitud Solicitud;
    private empleado emp;
    private ConsultaEliminarSolicitud consulta;

    public ControladroEliminarSolicitud(EliminarSolicitudPlano vista, cliente Cliente, solicitud Solicitud, empleado emp, ConsultaEliminarSolicitud consulta) {
        this.vista = vista;
        this.Cliente = Cliente;
        this.Solicitud = Solicitud;
        this.emp = emp;
        this.consulta = consulta;
        vista.btnBuscar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.elimSol=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnBuscar){
            if(vista.cajaNSolicitud.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "ingrese el Numero de la Solicitud");
            }else{
                Solicitud.setIdSolicitud(Integer.parseInt(vista.cajaNSolicitud.getText()));
                if(consulta.buscarSolicitud(Solicitud, Cliente, emp)){
                    vista.cajaIDsolicitud.setText(String.valueOf(Solicitud.getIdSolicitud()));
                    vista.cajaSolicitud.setText(
                            String.valueOf(Solicitud.getFechaSoli())+"\n"+
                            Solicitud.getHoraSoli()+"\n"+
                            "-----------------------------------"+"\n"+
                            Solicitud.getDetalleSoli()+"\n"+
                            "Cliente: "+Cliente.getNombreCliente()+" "+Cliente.getApellidosCliente()
                    );
                    vista.cajaRegistrado.setText(emp.getNombreEmpleado()+" "+emp.getApellidosPaterno()+" "+emp.getApellidosMaterno());
                }else{
                    JOptionPane.showMessageDialog(null, "No Se encontro la Solicitud Que Buscaba");
                }   
            }
        }
        if(e.getSource()==vista.btnEliminar){
            if(verificar()){
                Solicitud.setIdSolicitud(Integer.parseInt(vista.cajaNSolicitud.getText()));
                if(consulta.eliminarSolicitud(Solicitud)){
                    JOptionPane.showMessageDialog(null, "Solicitud Eliminado correctamente");
                    limpiarCajas();
                }else{
                    JOptionPane.showMessageDialog(null, "La Solicitud no se pudo eliminar");
                    limpiarCajas();
                }
            }else{
                JOptionPane.showMessageDialog(null, "Llene todos los campos");
            }
        }
        if(e.getSource()==vista.btnSalir){
            ControladorInicio.elimSol=null;
            vista.dispose();
            limpiarCajas();
        }
    }
    
    public void iniciar(){
        //Le establecemos paramteros ala vista
        vista.setTitle("Eliminar Solicitud de Servicio");
        vista.setLocationRelativeTo(null);
        //vista.setSize(420, 440);
        vista.setVisible(true);
        vista.btnEliminar.setEnabled(false);
        vista.cajaIDsolicitud.setVisible(false);
        vista.cajaSolicitud.setEditable(false);
        vista.cajaRegistrado.setEditable(false);
    }
    
    public boolean verificar(){
        if(vista.cajaSolicitud.getText().isEmpty() ||
        vista.cajaRegistrado.getText().isEmpty() ||
        vista.cajaAutorizado.getText().isEmpty() ||
        vista.cajaRegistrado.getText().isEmpty() ||
        vista.cajaMotivo.getText().isEmpty() ||
        vista.cajaMonto.getText().isEmpty() ||
        vista.cajaUnidad.getText().isEmpty()){
            return false;
        }else{
            return true;
        }
    }
    
    public void limpiarCajas(){
        vista.cajaIDsolicitud.setText(null);
        vista.cajaSolicitud.setText(null);
        vista.cajaRegistrado.setText(null);
        vista.cajaAutorizado.setText(null);
        vista.cajaRegistrado.setText(null);
        vista.cajaMotivo.setText(null);
        vista.cajaMonto.setText(null);
        vista.cajaUnidad.setText(null);
    }

}
