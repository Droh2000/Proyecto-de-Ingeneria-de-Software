package controlador;

import static controlador.ControladorInicio.vistaGenerarSolicitud;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaPlano;
import modelo.ConsultaServicio;
import modelo.cliente;
import modelo.plano;
import modelo.solicitud;
import modelo.usuario;
import vista.GenerarSolicitudServicio;
import vista.RegistroPlano;

public class ControladorServicio implements ActionListener{
    private GenerarSolicitudServicio interSoli;//Interfaz
    private cliente Cliente;//objeto con todos los atributos del cliente
    private solicitud Solicitud;
    private ConsultaServicio consuSeriv;
    private usuario user;
    private plano Plano;
    private boolean SoloRegistro=true;
    public static RegistroPlano vistaPlano;

    public ControladorServicio(GenerarSolicitudServicio interSoli,plano Plano,cliente Cliente, usuario user,solicitud Solicitud, ConsultaServicio consuSeriv) {
        this.interSoli = interSoli;
        this.Cliente = Cliente;
        this.Solicitud = Solicitud;
        this.user=user;
        this.Plano=Plano;
        this.consuSeriv = consuSeriv;
        //Para Buscar si existe la Razon Social
        interSoli.btnBuscar.addActionListener(this);
        interSoli.btnGuardar.addActionListener(this);
        interSoli.btnCancelar.addActionListener(this);
        interSoli.btnSalir.addActionListener(this);
        interSoli.btnEditar.addActionListener(this);
        interSoli.btnRegistrarCliente.addActionListener(this);
        interSoli.btnRegistrarPlano.addActionListener(this);
        interSoli.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.vistaGenerarSolicitud=null;
            }
        });
    }
    
    //En este caso hay varios botones, nececitamos saber cual boton a sido pulsado
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==interSoli.btnBuscar){
            if(interSoli.cajaRazonSocial.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Especifique la razon social del cliente");
            }else{
                 //Mandamos lo que la persona quiere buscar
                Cliente.setRazonSocial(interSoli.cajaRazonSocial.getText());//lo que la persona escribio para buscar ala persona
                //LLenar los datos en la Interfaz
                if(consuSeriv.buscarRazonSocial(Cliente, Solicitud)){
                    interSoli.cajaID.setText(String.valueOf(Cliente.getIdCliente()));
                    interSoli.cajaSolicitud.setText(String.valueOf(Solicitud.getIdSolicitud()));
                    interSoli.cajaFechaHora.setText(String.valueOf(Solicitud.getFechaSoli()+" - "+Solicitud.getHoraSoli()));
                    interSoli.cajaDetalle.setText(Solicitud.getDetalleSoli());
                    interSoli.cajaCodigo.setText(String.valueOf(Cliente.getIdCliente()));
                    interSoli.cajaNombre.setText(Cliente.getNombreCliente());
                    interSoli.cajaDireccion.setText(Cliente.getDireccion());
                    interSoli.cajaCiudad.setText(Cliente.getCiudad());
                    interSoli.cajaRazonNuevo.setText(Cliente.getRazonSocial());
                    interSoli.cajaApellido.setText(Cliente.getApellidosCliente());
                    interSoli.cajaTelefono.setText(Cliente.getTelefono());
                    interSoli.cajaEmail.setText(Cliente.getEmail());
                    activarCajasSolicitud();
                    activarCajasRegistro();
                    interSoli.btnRegistrarPlano.setEnabled(true);
                    interSoli.btnGuardar.setEnabled(false);
                }else{
                    //Cuando No se Encontro al cliente, se tiene que registrar
                    JOptionPane.showMessageDialog(null, "No existe un cliente con esa clave");
                }   
            }
        }
        if(e.getSource()==interSoli.btnRegistrarCliente){
            limpiarCajas();
            activarCajasRegistro();
            interSoli.cajaRazonSocial.setEnabled(false);
            interSoli.btnBuscar.setEnabled(false);
        }
        if(e.getSource()==interSoli.btnRegistrarPlano){
            if(vistaPlano==null){
                Plano.setIdCliente(Integer.parseInt(interSoli.cajaID.getText()));
                vistaPlano=new RegistroPlano();
                ConsultaPlano consulta=new ConsultaPlano();
                ControladorPlano control=new ControladorPlano(vistaPlano, consulta, Plano);
                control.Inicio();    
            }else{
                JOptionPane.showMessageDialog(null, "Ya tienes Abierta la Ventana");
            }
        }
        if(e.getSource()==interSoli.btnGuardar){
            if(SoloRegistro){//Sea para actualizar todo el registro del cliente
                if(Verificar()){
                    Cliente.setNombreCliente(interSoli.cajaNombre.getText());
                    Cliente.setApellidosCliente(interSoli.cajaApellido.getText());
                    Cliente.setRazonSocial(interSoli.cajaRazonNuevo.getText());
                    Cliente.setDireccion(interSoli.cajaDireccion.getText());
                    Cliente.setCiudad(interSoli.cajaCiudad.getText());
                    Cliente.setTelefono(interSoli.cajaTelefono.getText());
                    Cliente.setEmail(interSoli.cajaEmail.getText());
                    if(consuSeriv.registroClienteSolicitud(Cliente,user)){//Para Registrar el Cliente y La Solicitud
                       limpiarCajas();
                       JOptionPane.showMessageDialog(null,"Registro guardado Correctamente");
                    }else{
                       limpiarCajas();
                       JOptionPane.showMessageDialog(null,"No se pudo guardar");
                    }   
                }else{
                    JOptionPane.showMessageDialog(null,"Llene Todos Los Campos");
                }
            }else{//Sea para actualizar la descripcion
                Solicitud.setIdSolicitud(Integer.parseInt(interSoli.cajaSolicitud.getText()));
                Solicitud.setDetalleSoli(interSoli.cajaDetalle.getText());
                if(consuSeriv.modificarDetalleSolicitud(Solicitud)){
                    limpiarCajas();
                    JOptionPane.showMessageDialog(null,"Detalle guardado Correctamente");
                }else{
                    JOptionPane.showMessageDialog(null,"El detalle no se pudo guardar");
                    limpiarCajas();
                }
            }
        }
        if(e.getSource()==interSoli.btnCancelar){
            limpiarCajas();
        }
        if(e.getSource()==interSoli.btnSalir){
            ControladorInicio.vistaGenerarSolicitud=null;
            interSoli.dispose();
        }
        if(e.getSource()==interSoli.btnEditar){
            Cliente.setIdCliente(Integer.parseInt(interSoli.cajaCodigo.getText()));
            Cliente.setNombreCliente(interSoli.cajaNombre.getText());
            Cliente.setApellidosCliente(interSoli.cajaApellido.getText());
            Cliente.setRazonSocial(interSoli.cajaRazonNuevo.getText());
            Cliente.setDireccion(interSoli.cajaDireccion.getText());
            Cliente.setCiudad(interSoli.cajaCiudad.getText());
            Cliente.setTelefono(interSoli.cajaTelefono.getText());
            Cliente.setEmail(interSoli.cajaEmail.getText());
            Solicitud.setIdSolicitud(Integer.parseInt(interSoli.cajaSolicitud.getText()));
            Solicitud.setDetalleSoli(interSoli.cajaDetalle.getText());
            if(consuSeriv.actualizarDatosClienteDetalle(Cliente, Solicitud)){
                limpiarCajas();
                JOptionPane.showMessageDialog(null,"Registro guardado Correctamente");
            }else{
                limpiarCajas();
                JOptionPane.showMessageDialog(null,"Registro no se guardado Correctamente");
            }
        }
    }
    
    public void iniciar(){
        //Le establecemos paramteros ala vista
        interSoli.setTitle("Generar Solicitud de Servicio");
        interSoli.setLocationRelativeTo(null);
        interSoli.setSize(700, 545);
        interSoli.setVisible(true);
        interSoli.cajaID.setVisible(false);
        interSoli.cajaSolicitud.setEnabled(false);
        interSoli.cajaFechaHora.setEnabled(false);
        interSoli.cajaDetalle.setEnabled(false);
        interSoli.cajaCodigo.setEnabled(false);
        interSoli.cajaNombre.setEnabled(false);
        interSoli.cajaDireccion.setEnabled(false);
        interSoli.cajaCiudad.setEnabled(false);
        interSoli.cajaRazonNuevo.setEnabled(false);
        interSoli.cajaApellido.setEnabled(false);
        interSoli.cajaTelefono.setEnabled(false);
        interSoli.cajaEmail.setEnabled(false);
        interSoli.btnGuardar.setEnabled(false);
        interSoli.btnEditar.setEnabled(false);
        interSoli.btnRegistrarCliente.setEnabled(true);
        interSoli.btnRegistrarPlano.setEnabled(false);
    }
    
    public void activarCajasSolicitud(){
        interSoli.cajaDetalle.setEnabled(true);
        interSoli.btnEditar.setEnabled(true);
        SoloRegistro=false;
    }
    
    public void activarCajasRegistro(){
        interSoli.cajaNombre.setEnabled(true);
        interSoli.cajaDireccion.setEnabled(true);
        interSoli.cajaCiudad.setEnabled(true);
        interSoli.cajaRazonNuevo.setEnabled(true);
        interSoli.cajaApellido.setEnabled(true);
        interSoli.cajaTelefono.setEnabled(true);
        interSoli.cajaEmail.setEnabled(true);
        interSoli.btnGuardar.setEnabled(true);
    }
    
    public void limpiarCajas(){
        interSoli.cajaID.setText(null);
        interSoli.cajaSolicitud.setText(null);
        interSoli.cajaFechaHora.setText(null);
        interSoli.cajaDetalle.setText(null);
        interSoli.cajaCodigo.setText(null);
        interSoli.cajaNombre.setText(null);
        interSoli.cajaDireccion.setText(null);
        interSoli.cajaCiudad.setText(null);
        interSoli.cajaRazonNuevo.setText(null);
        interSoli.cajaApellido.setText(null);
        interSoli.cajaTelefono.setText(null);
        interSoli.cajaEmail.setText(null);
        interSoli.btnGuardar.setText(null);
        interSoli.btnEditar.setText(null);
    }
    
    public boolean Verificar(){
        if(interSoli.cajaNombre.getText().isEmpty() ||
        interSoli.cajaDireccion.getText().isEmpty() ||
        interSoli.cajaCiudad.getText().isEmpty() ||
        interSoli.cajaRazonNuevo.getText().isEmpty() ||
        interSoli.cajaApellido.getText().isEmpty() ||
        interSoli.cajaTelefono.getText().isEmpty() ||
        interSoli.cajaEmail.getText().isEmpty()){
            return false;
        }else{
            return true;
        }
    }
    
    
}
