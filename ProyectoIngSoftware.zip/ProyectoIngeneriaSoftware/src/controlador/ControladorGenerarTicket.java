package controlador;

import static controlador.ControladorInicio.VistaticketRegistro;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultasGenerarTicket;
import modelo.Ticket;
import modelo.cliente;
import modelo.empleado;
import modelo.solicitud;
import vista.GenerarTicketRegistro;

public class ControladorGenerarTicket implements ActionListener{
    private GenerarTicketRegistro vista;
    private cliente Cliente;//objeto con todos los atributos del cliente
    private solicitud Solicitud;
    private empleado emp;
    private Ticket ticket;
    private ConsultasGenerarTicket consulta;

    public ControladorGenerarTicket(GenerarTicketRegistro vista, cliente Cliente,Ticket ticket,solicitud Solicitud, empleado emp, ConsultasGenerarTicket consulta) {
        this.vista = vista;
        this.Cliente = Cliente;
        this.Solicitud = Solicitud;
        this.emp = emp;
        this.consulta = consulta;
        this.ticket=ticket;
        vista.btnBuscar.addActionListener(this);
        vista.btnGenerar.addActionListener(this);
        vista.btnCancelar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.btnImprimir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.VistaticketRegistro=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnBuscar){
            if(vista.cajaSolicitud.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Ingrese la Solicitud");
            }else{
                Solicitud.setIdSolicitud(Integer.parseInt(vista.cajaSolicitud.getText()));
                if(consulta.buscarSolicitud(Solicitud, Cliente, emp)){
                    vista.cajaCliente.setText(Cliente.getNombreCliente());
                    vista.cajaDetalle.setText(Solicitud.getDetalleSoli());
                    vista.cajaEncargado.setText(emp.getNombreEmpleado()+" "+emp.getApellidosPaterno()+" "+emp.getApellidosMaterno());
                    vista.cajaIDEmpl.setText(String.valueOf(emp.getIdEmpleado()));
                }else{
                    JOptionPane.showMessageDialog(null, "No Se encontro la Solicitud Que Buscaba");
                }
            }
        }
        if(e.getSource()==vista.btnGenerar){
            if(vista.cajaDetalle.getText().isEmpty() || vista.cajaTotal.getText().isEmpty() || vista.cajaIDEmpl.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Llene Todos los campos");
            }else{
               ticket.setDetalle(vista.cajaDetalle.getText());
               ticket.setTotal(Float.parseFloat(vista.cajaTotal.getText()));
               ticket.setIdEmpleado(Integer.parseInt(vista.cajaIDEmpl.getText()));
               if(consulta.registroTicket(ticket)){
                   JOptionPane.showMessageDialog(null, "Ticket Registrado Correctamente");
                   vista.btnImprimir.setEnabled(true);
               }else{
                   JOptionPane.showMessageDialog(null, "El Ticket no se pudo Registrar");
               }   
            }
        }
        if(e.getSource()==vista.btnCancelar){
            LimpiarCajas();
        }
        if(e.getSource()==vista.btnSalir){
            ControladorInicio.VistaticketRegistro=null;
            vista.dispose();
        }
        if(e.getSource()==vista.btnImprimir){
            JOptionPane.showMessageDialog(null, "Se Imprimio el Ticket Correctamente");
        }
    }
    
    public void iniciar(){
        //Le establecemos paramteros ala vista
        vista.setTitle("Generar Solicitud de Servicio");
        vista.setLocationRelativeTo(null);
        vista.setSize(420, 440);
        vista.setVisible(true);
        vista.btnImprimir.setEnabled(false);
        vista.cajaIDEmpl.setVisible(false);
        vista.cajaCliente.setEditable(false);
        vista.cajaEncargado.setEditable(false);
        vista.cajaTicket.setEnabled(false);
    }    
    
    public void LimpiarCajas(){
        vista.cajaIDEmpl.setText(null);
        vista.cajaCliente.setText(null);
        vista.cajaEncargado.setText(null);
        vista.cajaTicket.setText(null);
        vista.cajaDetalle.setText(null);
        vista.cajaSolicitud.setText(null);
    }

}
