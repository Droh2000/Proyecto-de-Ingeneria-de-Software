package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaRegistrarEstadoPlano;
import modelo.estadoPlano;
import vista.RegistrarEstadoPlano;

public class ControladorRegistrarEstadoPlano implements ActionListener{
    
    private RegistrarEstadoPlano vista;
    private ConsultaRegistrarEstadoPlano consulta;
    private estadoPlano estado;

    public ControladorRegistrarEstadoPlano(RegistrarEstadoPlano vista, ConsultaRegistrarEstadoPlano consulta, estadoPlano estado) {
        this.vista = vista;
        this.consulta = consulta;
        this.estado = estado;
        vista.btnCargar.addActionListener(this);
        vista.btnNuevo.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorPlano.vistaREP2=null;
                ControladorInicio.vistaREP=null;
                ControladorProcesarSolicitudPlano.resp=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnCargar){
            if(!"".equals(vista.cajaCodigo.getText())){
                estado.setIdEstado(Integer.parseInt(vista.cajaCodigo.getText()));
                vista.tablaVisualizacion.setModel(consulta.cargarEstados(estado));    
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese el Estado");
            }
        }
        if(e.getSource()==vista.btnNuevo){
            vista.cajaEstado.setEnabled(true);
            vista.cajaCodigo.setEnabled(false);
            vista.btnGuardar.setEnabled(true);
        }
        if(e.getSource()==vista.btnGuardar){
            estado.setEstado(vista.cajaEstado.getText());
            
            if(consulta.registroEstado(estado)){
                JOptionPane.showMessageDialog(null, "Estado Registrado Correctamente");
                vista.cajaEstado.setEnabled(false);
                vista.btnGuardar.setEnabled(false);
                vista.btnCargar.setEnabled(true);
                limpiarCajas();
            }else{
                JOptionPane.showMessageDialog(null, "El Estado no se pudo Registrar");
                vista.cajaEstado.setEnabled(false);
                vista.btnGuardar.setEnabled(false);
                vista.btnCargar.setEnabled(true);
                limpiarCajas();
            }
        }
        if(e.getSource()==vista.btnSalir){
            ControladorPlano.vistaREP2=null;
            ControladorInicio.vistaREP=null;
            ControladorProcesarSolicitudPlano.resp=null;
            vista.dispose();
        }
    }

    public void Inicio(){
        vista.setTitle("Registrar Estado Plano");
        vista.setLocationRelativeTo(null);
        vista.cajaEstado.setEnabled(false);
        vista.btnGuardar.setEnabled(false);
        //vista.setSize(420, 440);
        vista.setVisible(true);
    }
    
    public void limpiarCajas(){
        vista.cajaEstado.setText(null);
        vista.cajaCodigo.setText(null);
    }

    public void inicioPlano(){
        vista.setTitle("Registrar Estado Plano");
        vista.setLocationRelativeTo(null);
        vista.cajaEstado.setEnabled(false);
        vista.btnGuardar.setEnabled(false);
        vista.btnCargar.setEnabled(false);
        vista.btnNuevo.setEnabled(false);
        vista.cajaCodigo.setEnabled(false);
        vista.tablaVisualizacion.setModel(consulta.cargarTodaTabla());
        //vista.setSize(420, 440);
        vista.setVisible(true);
    } 
}
