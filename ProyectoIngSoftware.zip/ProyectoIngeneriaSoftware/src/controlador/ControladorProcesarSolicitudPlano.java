package controlador;

import static controlador.ControladorInicio.vistaPSP;
import static controlador.ControladorInicio.vistaREP;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import modelo.ConsultaProcesarSolicitudPlano;
import modelo.ConsultaRegistrarEstadoPlano;
import modelo.cliente;
import modelo.empleado;
import modelo.estadoPlano;
import modelo.plano;
import modelo.solicitud;
import vista.ProcesarSolicitudPlano;
import vista.RegistrarEstadoPlano;

public class ControladorProcesarSolicitudPlano implements ActionListener{
    private ProcesarSolicitudPlano vista;
    private cliente Cliente;//objeto con todos los atributos del cliente
    private solicitud Solicitud;
    private estadoPlano estado;
    private plano p;
    private ConsultaProcesarSolicitudPlano consulta;
    public static RegistrarEstadoPlano resp;

    public ControladorProcesarSolicitudPlano(ProcesarSolicitudPlano vista, cliente Cliente, solicitud Solicitud, estadoPlano estado, ConsultaProcesarSolicitudPlano consulta) {
        p=new plano();
        this.vista = vista;
        this.Cliente = Cliente;
        this.Solicitud = Solicitud;
        this.estado = estado;
        this.consulta = consulta;
        vista.btnCargar.addActionListener(this);
        vista.btnRegistrar.addActionListener(this);
        vista.btnGuardar.addActionListener(this);
        vista.btnBuscar.addActionListener(this);
        vista.btnImprimir.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.vistaPSP=null;
            }
        });
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnCargar){
            vista.tablaSolicitud.setModel(consulta.cargarSolicitud());
        }
        if(e.getSource()==vista.btnRegistrar){
            if(resp==null){
                resp=new RegistrarEstadoPlano();
                ConsultaRegistrarEstadoPlano consuREP=new ConsultaRegistrarEstadoPlano();
                ControladorRegistrarEstadoPlano contrREP=new ControladorRegistrarEstadoPlano(resp, consuREP, estado);
                contrREP.Inicio(); 
            }else{
                JOptionPane.showMessageDialog(null,"Ya esta Abierta la Ventana");
            }
        }
        if(e.getSource()==vista.btnGuardar){
            Date fecha=vista.txtFecha.getDate();
            long d=fecha.getTime();
            java.sql.Date soloFecha=new java.sql.Date(d);
            estado.setFechaEstado(soloFecha);
            estado.setIdEstado(Integer.parseInt(vista.txtIDestado.getText()));
            p.setIdPlano(Integer.parseInt(vista.txtIdPlano.getText()));
            if(consulta.registrarEstadoPlano(estado,p)){
                JOptionPane.showMessageDialog(null, "Estado del Plano Registrado Correctamente");
                if(consulta.actualizarEstadoFecha(estado)){
                    JOptionPane.showMessageDialog(null, "Fecha del Estado Registrado Correctamente");
                }else{
                    JOptionPane.showMessageDialog(null, "Fecha del Estado No Registrado");
                }
                vista.btnImprimir.setEnabled(true);
            }else{
                JOptionPane.showMessageDialog(null, "El Estado del Plano no se pudo Registrar");
            }
        }
        if(e.getSource()==vista.btnBuscar){
            if(!vista.txtbuscarSolicitud.getText().isEmpty()){
                Solicitud.setIdSolicitud(Integer.parseInt(vista.txtbuscarSolicitud.getText()));
                vista.tablaSolicitud.setModel(consulta.buscarSolicitud(Solicitud,p));
                if(consulta.encontrarIdPlano(Solicitud, p)){
                    vista.txtIdPlano.setText(String.valueOf(p.getIdPlano()));
                }
                vista.btnGuardar.setEnabled(true);
            }else{
                JOptionPane.showMessageDialog(null, "Ingrese el Numero de Solicitud a Buscar");
            }
        }
        if(e.getSource()==vista.btnImprimir){
            JOptionPane.showMessageDialog(null, "Se mando a Imprimir");
        }
        if(e.getSource()==vista.btnSalir){
            ControladorInicio.vistaPSP=null;
            vista.dispose();
        }
    }
    
    public void Iniciar(){
        vista.setTitle("Procesar Solicitud de Desarrollo de Planos");
        vista.setLocationRelativeTo(null);
        vista.btnGuardar.setEnabled(false);
        vista.txtIdPlano.setVisible(false);
        vista.btnImprimir.setEnabled(false);
        //vista.setSize(420, 440);
        vista.setVisible(true);
    }
}
