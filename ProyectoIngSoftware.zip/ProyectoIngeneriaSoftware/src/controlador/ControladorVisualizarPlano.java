package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import modelo.ConsultaVisualizarPlano;
import modelo.cliente;
import modelo.estadoPlano;
import modelo.plano;
import modelo.solicitud;
import vista.VisualizarPlano;

public class ControladorVisualizarPlano implements ActionListener{
    private VisualizarPlano vista;
    private ConsultaVisualizarPlano control;
    private solicitud s;
    private cliente c;
    private plano p;
    private estadoPlano est;

    public ControladorVisualizarPlano(VisualizarPlano vista, ConsultaVisualizarPlano control, solicitud s, cliente c, plano p, estadoPlano est) {
        this.vista = vista;
        this.control = control;
        this.s = s;
        this.c = c;
        this.p = p;
        this.est = est;
        vista.btnBuscar.addActionListener(this);
        vista.btnSalir.addActionListener(this);
        vista.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent we) {
                ControladorInicio.vistaVisualizarPlano=null;
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnBuscar){
            if(vista.cajaSolicitud.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Ingrese el numero de la solicitud a buscar");
            }else{
                s.setIdSolicitud(Integer.parseInt(vista.cajaSolicitud.getText()));
                if(control.buscarRazonSocial(s, c, p, est)){
                    vista.cajaCliente.setText(c.getNombreCliente()+" "+c.getApellidosCliente());
                    vista.cajaTipoPlano.setText(p.getTipo());
                    vista.cajaEstado.setText(est.getEstado());
                }else{
                    JOptionPane.showMessageDialog(null, "No se encontro esa Solicitud");
                }
            }
        }
        if(e.getSource()==vista.btnSalir){
            limpiarcajas();
            ControladorInicio.vistaVisualizarPlano=null;
            vista.dispose();
        }
    }
    
    public void inicio(){
        vista.setLocationRelativeTo(null);
        vista.setSize(751,570);
        vista.setVisible(true);
    }
    
    public void limpiarcajas(){
        vista.cajaSolicitud.setText(null);
        vista.cajaCliente.setText(null);
        vista.cajaTipoPlano.setText(null);
        vista.cajaEstado.setText(null);
    }
    
}
