package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import modelo.CifrarContraseña;
import modelo.CosultaLogin;
import modelo.usuario;
import vista.Login;

public class ControladorLogin implements ActionListener{
    private Login vista;
    private CosultaLogin consulta;
    private usuario user;
    public static ControladorInicio menuInicio;
    
    public ControladorLogin(Login vista, CosultaLogin consulta, usuario user) {
        this.vista = vista;
        this.consulta = consulta;
        this.user = user;
        vista.btnAceptr.addActionListener(this);
        vista.btnCancelar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.btnAceptr){
            String contraseña=new String(vista.cajaContraseña.getPassword());
            if(vista.cajaUsuario.getText().equals("") || contraseña.equals("")){
                JOptionPane.showMessageDialog(null, "Llene todos los campos");
            }else{
                //Tenemos que volver a encriptar la contraseña para verificar que es la misma
                String nuevaContr=CifrarContraseña.md5(contraseña);
                
                user.setNombreUser(vista.cajaUsuario.getText());
                user.setContraseña(nuevaContr);
                if(consulta.iniciarSesion(user)){//El usuario y contrseña es correcta
                    if(menuInicio==null){
                        vista.dispose();
                        menuInicio=new ControladorInicio(user);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Usuario/Contraseña No son Correctos");
                }
            }
        }
        if(e.getSource()==vista.btnCancelar){
            System.exit(0);
        }
    }
    
    public void iniciar(){
        vista.setTitle("Inicio de Sesion");
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }
}
